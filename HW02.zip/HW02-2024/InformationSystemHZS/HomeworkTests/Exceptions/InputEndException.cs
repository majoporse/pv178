﻿namespace HomeworkTests.Exceptions;

public class InputEndException : Exception
{
}