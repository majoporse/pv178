﻿using InformationSystemHZS;
using InformationSystemHZS.IO.Helpers;

// DO NOT TOUCH THIS ENTRY POINT
Runner.Main(new ConsoleManager());
