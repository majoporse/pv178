namespace InformationSystemHZS.Models.HelperModels;

public sealed class PositionDto
{
    public int X { get; set; }
    public int Y { get; set; }
}