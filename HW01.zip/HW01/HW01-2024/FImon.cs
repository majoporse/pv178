﻿using System;
using System.Xml.Linq;
using System.Xml.Schema;

namespace HW01_2024
{
    public abstract class FImon
    {
        public int Health{ get; set; }
        int maxHealth;
        public int AttackDamage{ get; set; }
        public double AttackSpeed{ get; init; }
        public int Xp { get; private set; }
        public int Level { get; private set; }
        /// <summary>
        /// setting also buffs the FImons hp and ad if threshold is reached
        /// 5 hp and ad for each level
        /// </summary>
        /// 
        public void Buff(int value)
        {
            Xp += value;
            int LvlDiff = (Xp - Level * 100) / 100;
            Level = Xp / 100;

            maxHealth += 3 * LvlDiff;
            AttackDamage += 2 * LvlDiff;
        }

        public void RestoreHp() { Health = maxHealth; }

        public string? Name { get; set; }
        public bool Alive { get { return Health > 0; } }

        public FImon(int health, int attackDamage, int attackSpeed, string name)
        {
            maxHealth = health;
            Health = maxHealth;
            AttackDamage = attackDamage;
            AttackSpeed = 1.0 / attackSpeed;
            Name = name;
        }

        public abstract void Attack(FImon f, string prefix);
        protected void BasicPrint(string prefix) 
        { Console.Write($"{prefix} Name: {Name,12} | Attack damage: {AttackDamage,3} | Health: {Health,3} | Attack speed: {(1 / AttackSpeed),3:F0} | Level: {Level,3} | Xp: {Xp % 100}"); }
        public abstract void Print(string prefix);
        private void BasicAttack(FImon f, string s) 
        {
            Console.Write($"{s} FImon: {f.Name,12} just dealt { f.AttackDamage} damage to {Name,12}\n");
            Health -= f.AttackDamage;
        }
        public virtual void RecieveAttack(LeafFImon f, string s) { BasicAttack(f, s); }
        public virtual void RecieveAttack(FireFImon f, string s) { BasicAttack(f, s); }
        public virtual void RecieveAttack(WaterFImon f, string s) { BasicAttack(f, s); }
    }

    public class LeafFImon : FImon
    {
        public override void Print(string prefix)
        {
            BasicPrint(prefix); Console.Write(" | Type: Leaf\n");
        }
        public override void Attack(FImon f, string s) { f.RecieveAttack(this, s); }
        public override void RecieveAttack(FireFImon f, string s)
        {
            Console.WriteLine($"{s} FImon: {f.Name,12} just dealt critical strike for {2 * f.AttackDamage} to {Name}");
            Health -= 2 * f.AttackDamage;
        }
        public LeafFImon( int attackDamage, int health, int attackSpeed, string name) : base(health, attackDamage, attackSpeed, name) { }
    }

    public class WaterFImon: FImon
    {
        public override void Print(string prefix) { BasicPrint(prefix); Console.Write(" | Type: Water\n"); }
        public override void Attack(FImon f, string s) { f.RecieveAttack(this, s); }

        public override void RecieveAttack(LeafFImon f, string s)
        {
            Console.WriteLine($"{s} FImon: {f.Name,12} just dealt critical strike for {2 * f.AttackDamage} to {Name}");
            Health -= 2 * f.AttackDamage;
        }
        public WaterFImon( int attackDamage, int health, int attackSpeed, string name) : base(health, attackDamage, attackSpeed, name) { }
    }

    public class FireFImon : FImon
    {
        public override void Print(string prefix) { BasicPrint(prefix); Console.Write(" | Type: Fire\n"); }
        public override void Attack(FImon f, string s) { f.RecieveAttack(this, s); }

        public override void RecieveAttack(WaterFImon f, string s)
        {
            Console.WriteLine($"{s} FImon: {f.Name,12} just dealt critical strike for {2 * f.AttackDamage} to {Name}");
            Health -= 2 * f.AttackDamage;
        }
        public FireFImon( int attackDamage, int health, int attackSpeed, string name): base(health, attackDamage, attackSpeed, name) { }
    }
}
