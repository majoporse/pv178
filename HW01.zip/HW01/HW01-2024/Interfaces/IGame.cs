﻿namespace HW01_2024.Interfaces
{
    public interface IGame
    {
        /// <summary>
        /// Starts the game.
        /// </summary>
        public bool Start();
    }
}
