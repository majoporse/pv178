﻿namespace HW01_2024.Interfaces
{
    public interface IBattle
    {
        /// <summary>
        /// Performs a battle between two trainers.
        /// </summary>
        /// <param name="player">Player trainer</param>
        /// <param name="enemy">Enemy trainer</param>
        /// <returns>Winner trainer</returns>
        //TODO:
        int TrainerDuel(Trainer t1, Trainer t2); //i wanted to use static methods so i find this interface kind of useless...

        /// <summary>
        /// Performs one round of a battle between two FImons.
        /// </summary>
        /// <param name="playerFImon">Player trainer's FImon</param>
        /// <param name="enemyFImon">Enemy trainer's FImon</param>
        /// <returns>Winner FImon</returns>
        //TODO:
        (int, int) FImonDuel(FImon f1, FImon f2);
    }
}
