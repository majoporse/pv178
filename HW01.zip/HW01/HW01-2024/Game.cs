﻿using HW01_2024.Interfaces;
using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Linq;
using System.Reflection.Metadata.Ecma335;

namespace HW01_2024
{

    public class Duel: IBattle
    {
        static bool PrintFight = false;
        
        public int TrainerDuel(Trainer t1, Trainer t2)
        {
            int t1FImonPos = t1.PickedFImons.FindIndex(0, a => a.Alive);
            int t2FImonPos = t2.PickedFImons.FindIndex(0, a => a.Alive);

            double time = 0, f1time = 0, f2time = 0;
            for (int round = 1; t1FImonPos < t1.FImons && t2FImonPos < t2.FImons;)
            {
                Console.WriteLine($"[[[[[.....ROUND {round++} START.....]]]]]");
                var (t1Res, t2Res) = FImonDuel(t1.PickedFImons[t1FImonPos], t2.PickedFImons[t2FImonPos], ref time, ref f1time, ref  f2time);
                t1FImonPos += t1Res;
                t2FImonPos += t2Res;
            }
            string winner = (t1FImonPos < t1.FImons ? t1 : t2).Name;
            Console.WriteLine($"[[[...{winner} has won the round...]]]");
            t1.HealFImons();
            t2.HealFImons();

            return t1FImonPos < t1.FImons ? 0 : 1; //this means that t1s FImons stayed alive
        }

        public (int, int) FImonDuel(FImon f1, FImon f2)
        {
            double a = 0, b = 0;
            double time = 0;
            return FImonDuel(f1, f2, ref time, ref a,ref b);
        }

        public (int, int) FImonDuel(FImon f1, FImon f2, ref double time, ref double f1time, ref double f2time)
        {
            f1.Print("||");
            f2.Print("||");
            while (f1.Alive && f2.Alive)
            {
                if ((f1time + f1.AttackSpeed - time) < (f2time + f2.AttackSpeed - time))
                {
                    f1time += f1.AttackSpeed;
                    time = f1time;
                    f1.Attack(f2, "==");
                } 
                else if ((f1time + f1.AttackSpeed - time) > (f2time + f2.AttackSpeed - time))
                {
                    f2time += f2.AttackSpeed;
                    time = f2time;
                    f2.Attack(f1, "==");
                }
                else
                {
                    f1time += f1.AttackSpeed;
                    f2time += f2.AttackSpeed;
                    time += f1.AttackSpeed;
                    f1.Attack(f2, "==");
                    f2.Attack(f1, "==");
                }
                f1.Print("||");
                f2.Print("||");
                Console.WriteLine();
            }
            f1time = f2time = time;
            return (f1.Alive ? 0 : 1, f2.Alive ? 0 : 1);
        }
    }
    public class Game: IGame
    {
        static string HelpString = @"---------------------
Controls:
To start the game type: start <position> <position> <position>
To check your FImons type: check
To check your opponents FImons type: info
To change the attack order of your FImons type: sort
After typing sort type the positions as following: <position1> <position2> <position3>
If you are ready to fight your opponent type: fight
To quit the game type: quit
If you want to see controls again, type: help
For testing purposes there is 6th character that wins all (basically)
---------------------
";

        public static readonly (int, int, int, string, string)[] FImonDesc = [
            (6, 4, 4, "Aquafin", "Water"),
            (4, 6, 4, "Embergeist", "Fire"),
            (5, 6, 4, "Photosprout", "Leaf"),
            (3, 6, 5, "Splashback", "Water"),
            (2, 10, 3, "Pyroclaw", "Fire"),
            (6, 10, 2, "Petalshade", "Leaf"),
        ];

        public static void PrintDesc()
        {
            Console.Write(HelpString);
            foreach (var FImon in FImonDesc)
            {
                Console.WriteLine($"Name: {FImon.Item4,12} | Attack damage: {FImon.Item1,3} | Health: {FImon.Item2,3} | Attack speed: {FImon.Item3,3} | Type: {FImon.Item5}");
            }
            Console.WriteLine("---------------------");
        }

        public static readonly Func<FImon>[] FImonMakers = [
                () => new WaterFImon(6, 4, 4, "Aquafin"),
                () => new FireFImon(4, 6, 4, "Embergeist"),
                () => new LeafFImon(5, 6, 4, "Photosprout"),
                () => new WaterFImon(3, 6, 5, "Splashback"),
                () => new FireFImon(2, 10, 3, "Pyroclaw"),
                () => new LeafFImon(6, 10, 2, "Petalshade"),
                () => new LeafFImon(15, 15, 5, "ronnie coleman"),
                () => new WaterFImon(2, 9, 5, "Maritide"),
                () => new FireFImon(2, 15, 4, "Incendrake"),
                () => new LeafFImon(6, 1, 5, "Sylvasprint"),
        ];

        Trainer User = new Trainer("User", 0);
        Trainer[] NPCS = [new Trainer("Miro", 0), new Trainer("Jožo", 100), new Trainer("Maroš", 200)];
        int current = 0;
        Duel duel = new Duel();

        public Game(List<int> fimons) 
        { 
            User.PickCharacters(fimons);
            NPCS[0].PickCharacters([7, 8, 9]);
            NPCS[1].PickCharacters([1, 3, 5]);
            NPCS[2].PickCharacters([0, 2, 1]);
        }

        public bool Start()
        {
            string input;
            while ((input = Console.ReadLine()) != "quit")
            {
                if (input == "info")
                {
                    NPCS[current].PrintCharacters();
                }
                else if (input == "check")
                {
                    User.PrintCharacters();    
                }
                else if (input == "sort")
                {
                    User.PrintCharacters();
                    Console.WriteLine("Choose your attack order!");
                    var positions = new List<int>();
                    while (positions.Count == 0)
                    {
                        var strs = Console.ReadLine().Split(' ');
                        for (int i = 0; i < strs.Length; ++i)
                        {
                            if (!int.TryParse(strs[i], out var num) || positions.Contains(num))
                            {
                                Console.WriteLine("Error parsing! Try again!");
                                positions.RemoveAll( x => true);
                                break;
                            }
                            positions.Add(num);
                        }
                    }
                    User.ChangePositions(positions);
                }
                else if (input == "fight")
                {
                    Console.WriteLine("---------------------");
                    ref Trainer curTrainer = ref NPCS[current];
                    if (duel.TrainerDuel(User, curTrainer) == 1)
                    {
                        Console.WriteLine($"you lost against: {curTrainer.Name}, you recieve up to 199xp");
                        User.LevelUp(199);
                    }
                    else
                    {
                        // User has won
                        User.LevelUp(499);
                        current++;
                        Console.WriteLine("You won! You recieve up to 499 xp!");
                    }
                    Console.WriteLine("---------------------");
                    if (current == NPCS.Length)
                        return true;
                }
                else if (input == "help")
                {
                    Console.Write(HelpString);
                }
                else if (input == "opponents")
                {
                    foreach (var NPC in NPCS) { NPC.PrintInfo(); }
                }
                else
                {
                    Console.WriteLine("worng input, try again...");
                }
            }
            return true;
        }
    }
}
