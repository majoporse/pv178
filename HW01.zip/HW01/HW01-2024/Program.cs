﻿using System;
using System.Collections.Generic;
using System.Globalization;

namespace HW01_2024
{

    class Program
    {
        static int Main(string[] args)
         {
            Game.PrintDesc();
            string read = Console.ReadLine();
            if (read == null || !read.StartsWith("start "))
                return 1;

            var splitted = read.Substring(6).Split(' ');
            if (splitted.Length != 3)
            {
                Console.WriteLine("bad input!");
                return 1;
            }
            List<int> ints = new List<int>();

            foreach (var item in splitted)
            {
                if (!int.TryParse(item, out var value))
                {
                    Console.WriteLine($"error parsing value: {item}!");
                    return 1;
                }
                ints.Add(value);
            }

            Game g = new Game(ints);
            if (g.Start())
                Console.WriteLine("***************YOU WON***************");

            return 0;
        }
    }
}
