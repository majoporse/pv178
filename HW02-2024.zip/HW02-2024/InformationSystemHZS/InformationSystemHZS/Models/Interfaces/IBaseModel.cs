﻿namespace InformationSystemHZS.Models.Interfaces;

public interface IBaseModel
{
    public string Callsign { get; set; }
}

