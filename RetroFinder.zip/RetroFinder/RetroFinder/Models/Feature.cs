﻿using System.Text.Json.Serialization;
using System.Xml.Serialization;

namespace RetroFinder.Models
{
    public class Feature
    {
        public FeatureType Type { get; set; } = new();
        public (int start, int end) Location { get; set; }

        public int Score;
    }
}
