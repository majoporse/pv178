﻿using RetroFinder.Domains;
using RetroFinder.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace RetroFinder;

public class SequenceAnalysis
{
    public FastaSequence Sequence { get; set; }

    public IEnumerable<FastaSequence> Domains { get; set; }

    public IEnumerable<Transposon> Transposons { get; set; }

    public void Analyze()
    {
        LTRFinder ltrFinder = new() { Sequence = Sequence };
        var trans = ltrFinder.IdentifyElements().ToList();

        foreach(var transposon in trans)
        {
            var ltrl = transposon.Features.Where(f => f.Type == FeatureType.LTRLeft).First();
            var ltrr = transposon.Features.Where(f => f.Type == FeatureType.LTRRight).First();

            DomainFinder domainFinder = new() 
            {
                Pos = ltrl.Location.end,
                input = Sequence.Sequence.Substring(ltrl.Location.end, ltrr.Location.start - ltrl.Location.end),
                sequences = Domains
            };
            var features = domainFinder.IdentifyDomains();
            DomainPicker domainPicker = new()
            {
                inputFeatures = features.ToList(),
            };

            var transList = transposon.Features.ToList();
            transList.AddRange(domainPicker.PickDomains());
            transList.Sort((a, b) => a.Location.start.CompareTo(b.Location.start));
            transposon.Features = transList;
        }
        Transposons = trans;
    }
}
