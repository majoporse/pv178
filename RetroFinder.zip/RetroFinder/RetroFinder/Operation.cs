﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RetroFinder;

enum Operation
{
    EXIT,
    NEW_FILE,
    NEW_DOMAIN,
    NO_OPERATION
}