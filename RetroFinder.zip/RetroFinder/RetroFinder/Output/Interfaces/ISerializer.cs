﻿namespace RetroFinder.Output.Interfaces;

public interface ISerializer
{
    void SerializeAnalysisResult(SequenceAnalysis analysis);
}
