﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace RetroFinder.DTOs;

[XmlType("Location")]
public class LocationDTO
{
    [XmlAttribute("Start")]
    public int Start { get; set; }
    [XmlAttribute("End")]
    public int End { get; set; }

    public LocationDTO()
    {
    }

    public LocationDTO((int, int) location)
    {
        Start = location.Item1;
        End = location.Item2;
    }
}
