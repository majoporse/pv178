﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using RetroFinder.Models;
using RetroFinder.Output;
using RetroFinder.Output.Interfaces;
using Spectre.Console;

namespace RetroFinder
{
    public class RetroFinder
    {

        public event Action<SequenceAnalysis> OnPrint;

        public IEnumerable<FastaSequence> Domains;

        public SequenceAnalysis Result;

        public int numThreads = 1;

        static IEnumerable<FastaSequence> tryparse(string Path)
        {
            //try catch if meant for wrong file path
            try
            {
                FastaUtils fastaUtils = new();
                if (!fastaUtils.Validate(Path)) //i dont like this but ¯\_(ツ)_/¯
                    throw new Exception("Invalid format");

                return fastaUtils.Parse(Path); //i dont like this but ¯\_(ツ)_/¯
            } catch (Exception e)
            {
                AnsiConsole.MarkupLine($"[red]{e.Message}[/]");
                return new List<FastaSequence>();
            }
        }

        public void addDomains(string path)
        {
            Domains = tryparse(path);
        }

        public void Analyze(string path)
        {
            var inputs = tryparse(path);

            if (Domains == null)
            {
                AnsiConsole.MarkupLine("[red]Add domains first![/]");
                return;
            }

            AnsiConsole.MarkupLine("[green]Analyzing...[/]");

            Parallel.ForEach(
                inputs,
                new ParallelOptions { MaxDegreeOfParallelism = numThreads },
                input =>
                {
                    SequenceAnalysis sequenceAnalysis = new() { Sequence = input, Domains = Domains };
                    sequenceAnalysis.Analyze();
                    OnPrint.Invoke(sequenceAnalysis);
                });
        }
    }
}
