public class Location
{
    public int Start { get; set; }
    public int End { get; set; }
}
